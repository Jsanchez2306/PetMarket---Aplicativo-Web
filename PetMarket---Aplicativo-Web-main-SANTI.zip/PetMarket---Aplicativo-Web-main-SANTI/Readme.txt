Login:

Usuario: admin@petmarket.com
Contraseña: admin123

Uso de font Awesome:

El proyecto incluye Font Awesome para iconos

se coloca el CDN en el html o se descarga desde la pagina oficial: "https://fontawesome.com"

Solo se pone 
<i> o <span> y la clase de icono
el "fas" es para iconos solidos
el "fab" es para redes sociales y marcas
el "far" es para iconos con contorno

Ejemplo de uso: 
<i class="fab fa-github"></i> (Es el icono de GitHub)
<i class="fab fa-twitter"></i> (Es el icono de twitter)
<i class="fas fa-home"></i> (Es el icono de una casita)
<i class="fas fa-shopping-cart"> (Es el icono de un carrito)

